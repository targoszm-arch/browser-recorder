let recorder;
let chunks = [];
let streams = [];
let filename = 'workflow.webm';

chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  if (message.target !== 'offscreen') return;
  if (message.type === 'OFFSCREEN_START') start(message).then(() => respond({ ok: true })).catch((e) => respond({ ok: false, error: e.message }));
  if (message.type === 'OFFSCREEN_STOP') stop().then(() => respond({ ok: true })).catch((e) => respond({ ok: false, error: e.message }));
  return true;
});

async function start({ streamId, includeMic, filename: requestedName }) {
  filename = requestedName;
  const tabStream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } },
    video: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId }, optional: [{ maxFrameRate: 30 }] }
  });
  streams = [tabStream];
  const audioContext = new AudioContext();
  const mix = audioContext.createMediaStreamDestination();
  if (tabStream.getAudioTracks().length) {
    const tabAudio = audioContext.createMediaStreamSource(new MediaStream(tabStream.getAudioTracks()));
    tabAudio.connect(mix);
    tabAudio.connect(audioContext.destination);
  }
  if (includeMic) {
    try {
      const mic = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false });
      streams.push(mic);
      audioContext.createMediaStreamSource(mic).connect(mix);
    } catch (error) {
      console.warn('Microphone unavailable; recording continues without voice.', error);
    }
  }
  const output = new MediaStream([...tabStream.getVideoTracks(), ...mix.stream.getAudioTracks()]);
  const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus') ? 'video/webm;codecs=vp9,opus' : 'video/webm';
  chunks = [];
  recorder = new MediaRecorder(output, { mimeType, videoBitsPerSecond: 5_000_000 });
  recorder.ondataavailable = (event) => event.data.size && chunks.push(event.data);
  recorder.start(1000);
}

async function stop() {
  if (!recorder || recorder.state === 'inactive') return;
  await new Promise((resolve) => { recorder.onstop = resolve; recorder.stop(); });
  streams.forEach((stream) => stream.getTracks().forEach((track) => track.stop()));
  const blob = new Blob(chunks, { type: recorder.mimeType });
  const url = URL.createObjectURL(blob);
  await chrome.downloads.download({ url, filename, saveAs: true });
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
  chunks = [];
}

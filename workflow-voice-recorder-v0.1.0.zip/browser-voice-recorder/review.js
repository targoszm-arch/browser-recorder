let session;
const q = (value) => JSON.stringify(value ?? '');
const slug = (value) => (value || 'workflow').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60);

function playwright(s) {
  const lines = [`import { test, expect } from '@playwright/test';`, '', `test(${q(s.title)}, async ({ page }) => {`, `  await page.goto(${q(s.startUrl)});`];
  for (const step of s.steps) {
    if (step.action === 'click') lines.push(`  await page.locator(${q(step.selector)}).click();`);
    if (step.action === 'fill' && step.value !== '<REDACTED>') lines.push(`  await page.locator(${q(step.selector)}).fill(${q(step.value)});`);
    if (step.action === 'fill' && step.value === '<REDACTED>') lines.push(`  await page.locator(${q(step.selector)}).fill(process.env.RECORDED_SECRET ?? '');`);
    if (step.action === 'select') lines.push(`  await page.locator(${q(step.selector)}).selectOption(${q(step.value)});`);
    if (step.action === 'key') lines.push(`  await page.locator(${q(step.selector)}).press(${q(step.key)});`);
    if (step.action === 'navigate') lines.push(`  await page.waitForURL(${q(step.value)});`);
  }
  return [...lines, '});', ''].join('\n');
}

function devtools(s) {
  const steps = [{ type: 'navigate', url: s.startUrl, assertedEvents: [{ type: 'navigation', url: s.startUrl, title: s.title }] }];
  for (const step of s.steps) {
    const selectors = [[step.selector || 'body']];
    if (step.action === 'click') steps.push({ type: 'click', target: 'main', selectors, offsetX: 1, offsetY: 1 });
    if (step.action === 'fill') steps.push({ type: 'change', value: step.value === '<REDACTED>' ? '' : step.value, selectors, target: 'main' });
    if (step.action === 'select') steps.push({ type: 'change', value: step.value, selectors, target: 'main' });
    if (step.action === 'key') steps.push({ type: 'keyDown', key: step.key, target: 'main' });
    if (step.action === 'navigate') steps.push({ type: 'navigate', url: step.value });
  }
  return JSON.stringify({ title: s.title, steps }, null, 2);
}

async function download(filename, body, mime) { await chrome.runtime.sendMessage({ type: 'DOWNLOAD_TEXT', filename, body, mime }); }

(async () => {
  session = (await chrome.storage.local.get('latestSession')).latestSession;
  if (!session) { document.querySelector('#title').textContent = 'No recording yet'; return; }
  document.querySelector('#title').textContent = session.title;
  document.querySelector('#meta').textContent = `${session.steps.length} steps · ${Math.round((session.durationMs || 0) / 1000)} seconds · ${session.startUrl}`;
  document.querySelector('#steps').innerHTML = session.steps.map((step) => `<li><span>${step.action}</span><code>${escapeHtml(step.name || step.selector || step.value || '')}</code><small>${(step.offsetMs / 1000).toFixed(1)}s</small></li>`).join('');
})();
function escapeHtml(value) { const el = document.createElement('span'); el.textContent = value; return el.innerHTML; }
document.querySelector('#playwright').addEventListener('click', () => download(`${slug(session.title)}.spec.ts`, playwright(session), 'text/typescript'));
document.querySelector('#devtools').addEventListener('click', () => download(`${slug(session.title)}.devtools.json`, devtools(session), 'application/json'));

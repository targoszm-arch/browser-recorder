const state = { recording: false, tabId: null, session: null };

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') await chrome.storage.local.set({ latestSession: null });
});

chrome.commands.onCommand.addListener((command) => {
  if (command === 'toggle-recording') state.recording ? stopRecording() : startRecording();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === 'offscreen') return false;
  (async () => {
    await hydrateState();
    if (message.type === 'GET_STATE') return { recording: state.recording, session: state.session };
    if (message.type === 'START') return startRecording(message.options || {});
    if (message.type === 'STOP') return stopRecording();
    if (message.type === 'EVENT' && state.recording && sender.tab?.id === state.tabId) {
      state.session.steps.push({ ...message.event, offsetMs: Date.now() - state.session.startedAt });
      await chrome.storage.local.set({ latestSession: state.session });
      await persistActiveState();
      return { ok: true };
    }
    if (message.type === 'DOWNLOAD_TEXT') {
      const url = `data:${message.mime || 'text/plain'};charset=utf-8,${encodeURIComponent(message.body)}`;
      await chrome.downloads.download({ url, filename: message.filename, saveAs: true });
      return { ok: true };
    }
  })().then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

async function ensureOffscreen() {
  const url = chrome.runtime.getURL('offscreen.html');
  const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [url] });
  if (!contexts.length) await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['USER_MEDIA'], justification: 'Record the selected browser tab and optional microphone audio' });
}

async function hydrateState() {
  if (state.recording) return;
  const { activeSession } = await chrome.storage.local.get('activeSession');
  if (!activeSession) return;
  state.recording = true;
  state.tabId = activeSession.tabId;
  state.session = activeSession.session;
}

async function persistActiveState() {
  if (!state.recording) return chrome.storage.local.remove('activeSession');
  return chrome.storage.local.set({ activeSession: { tabId: state.tabId, session: state.session } });
}

async function startRecording(options = {}) {
  if (state.recording) return { ok: false, error: 'A recording is already running.' };
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !/^https?:/.test(tab.url || '')) throw new Error('Open a normal web page before recording.');
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  await ensureOffscreen();
  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
  const id = crypto.randomUUID();
  state.recording = true;
  state.tabId = tab.id;
  state.session = { id, title: options.title || tab.title || 'Browser workflow', startedAt: Date.now(), startUrl: tab.url, steps: [] };
  await chrome.storage.local.set({ latestSession: state.session, recordingTabId: tab.id });
  await persistActiveState();
  await chrome.runtime.sendMessage({ type: 'OFFSCREEN_START', target: 'offscreen', streamId, includeMic: options.includeMic !== false, filename: `workflow-${id}.webm` });
  await chrome.tabs.sendMessage(tab.id, { type: 'RECORDER_STATE', recording: true });
  await chrome.action.setBadgeText({ text: 'REC', tabId: tab.id });
  await chrome.action.setBadgeBackgroundColor({ color: '#dc2626', tabId: tab.id });
  return { ok: true, session: state.session };
}

async function stopRecording() {
  await hydrateState();
  if (!state.recording) return { ok: false, error: 'No recording is running.' };
  const tabId = state.tabId;
  state.session.endedAt = Date.now();
  state.session.durationMs = state.session.endedAt - state.session.startedAt;
  await chrome.storage.local.set({ latestSession: state.session });
  try { await chrome.tabs.sendMessage(tabId, { type: 'RECORDER_STATE', recording: false }); } catch {}
  await chrome.runtime.sendMessage({ type: 'OFFSCREEN_STOP', target: 'offscreen' });
  await chrome.action.setBadgeText({ text: '', tabId });
  state.recording = false;
  state.tabId = null;
  const session = state.session;
  state.session = null;
  await persistActiveState();
  await chrome.tabs.create({ url: chrome.runtime.getURL('review.html') });
  return { ok: true, session };
}

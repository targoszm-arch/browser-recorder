# Workflow Voice Recorder

An installable Chrome/Chromium Manifest V3 extension that records a browser workflow as:

- Playwright test (`.spec.ts`)
- Chrome DevTools Recorder flow (`.devtools.json`)
- Screen recording with tab audio and optional microphone narration (`.webm`)

Everything stays local. Password and payment-card fields are redacted from generated test data.

## Install

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Choose **Load unpacked** and select this folder.
4. Pin **Workflow Voice Recorder**.
5. Open an HTTPS page, click the extension, choose whether to include the microphone, and click **Start recording**.
6. Complete the workflow. Click the extension again and choose **Stop and export**.

Chrome asks for microphone access the first time. The video downloads as WebM. A review tab opens for Playwright and DevTools JSON export.

## Current scope

The recorder captures clicks, changed form values, select changes, Enter/Escape/Tab keys, submissions, and same-tab URL changes. It masks password and credit-card autocomplete fields. It records the visible browser tab; browser chrome, extension popups and other applications are not included.

## Production hardening backlog

- IndexedDB session store and recovery after service-worker restart
- Screenshot-per-step capture and visual step editor
- File upload, drag/drop, native dialog, iframe and shadow-DOM handling
- Locator scoring with role/text/test-id fallbacks
- MP4 transcoding (WebM is the browser-native zero-backend output)
- Automated Chrome Web Store packaging, privacy disclosures and end-to-end tests
